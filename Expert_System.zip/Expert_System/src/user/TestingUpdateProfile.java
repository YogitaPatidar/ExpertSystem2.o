package user;

import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestingUpdateProfile
 */
@WebServlet("/TestingUpdateProfile")
public class TestingUpdateProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// UPDATE `testing` SET `name` = 'Testing1', `password` = '123123' WHERE `testing`.`userid` = 2
		try{
			
		Class.forName("com.mysql.jdbc.Driver");
	    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
	    Statement st = conn.createStatement();
		ResultSet res=st.executeQuery("select * from testing where userid=1");
		while(res.next()){
			if(res.getString("password").equals(request.getParameter("oldpwd"))){
				if(res.getString("password").equals(request.getParameter("newpwd"))){
					response.sendRedirect("user/testingConfirmPassword.jsp?q=Old and New Passwords are same...");
				}
				else{
					if(request.getParameter("newpwd").equals(request.getParameter("confirmpwd"))){
						int x=st.executeUpdate("UPDATE `testing` SET `password` = '"+request.getParameter("newpwd")+"' WHERE `testing`.`userid` = 1");
						response.sendRedirect("user/testingConfirmPassword.jsp?q=Password updated...");
					}
					else{
						response.sendRedirect("user/testingConfirmPassword.jsp?q=Password mismatch...");
					}
				}
				
				
				
				
			}
			else{
				response.sendRedirect("user/testingConfirmPassword.jsp?q= Enter correct Password");
				
			}
		}
		}
		catch(Exception e){
			
		}
	}

}

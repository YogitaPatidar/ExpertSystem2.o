package user;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.*;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.oreilly.servlet.MultipartRequest;

/**
 * Servlet implementation class Testing
 */
@MultipartConfig
@WebServlet("/Testing")
 
public class Testing extends HttpServlet {
	private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
        Part file=request.getPart("image");
        
        String imageFileName=file.getSubmittedFileName();// get selected image file name
        System.out.println(imageFileName);
        
        // upload path where the original image is going to be uploaded
        String uploadPath="C:/Users/lenovo/workspace/Expert_System/WebContent/user/images/"+imageFileName; 
        System.out.print(uploadPath);
        
        // Uploading image into images folder
        try{
	        FileOutputStream fos=new FileOutputStream(uploadPath);
	        InputStream is=file.getInputStream();
	        
	        byte[] data=new byte[is.available()];
	        is.read(data);
	        fos.write(data);
	        fos.close();
        }
        catch(Exception e){
        	e.printStackTrace();
        }
        
        // Database connectivity
        try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
        Statement st = conn.createStatement();
        int x=st.executeUpdate("update testing  SET `img` = '"+imageFileName+"' WHERE `testing`.`userid` = 1");
            
        if(x!=0){
        	
        	response.sendRedirect("user/testing.jsp?q="+imageFileName);
        }
        else{
        	response.sendRedirect("user/testing.jsp?q=Retry...");
        }
        }
        catch(Exception e){
        	
        }
    	
    	
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

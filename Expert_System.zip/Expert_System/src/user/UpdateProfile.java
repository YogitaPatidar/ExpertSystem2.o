package user;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

/**
 * Servlet implementation class UpdateProfile
 */
@MultipartConfig
@WebServlet("/UpdateProfile")
public class UpdateProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
Part file=request.getPart("image");
        
        String imageFileName=file.getSubmittedFileName();// get selected image file name
        System.out.println(imageFileName);
        
        // upload path where the original image is going to be uploaded
        String uploadPath="C:/Users/lenovo/workspace/Expert_System/WebContent/user/images/"+imageFileName; 
        System.out.print(uploadPath);
        
        // Uploading image into images folder
        try{
	        FileOutputStream fos=new FileOutputStream(uploadPath);
	        InputStream is=file.getInputStream();
	        
	        byte[] data=new byte[is.available()];
	        is.read(data);
	        fos.write(data);
	        fos.close();
        }
        catch(Exception e){
        	e.printStackTrace();
        }
        
        // Database connectivity
        try{
        	HttpSession session=request.getSession();
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
        Statement st = conn.createStatement();
        int x=st.executeUpdate("update user  SET `img` = '"+imageFileName+"' WHERE userid='"+session.getAttribute("userid")+"'");
            
        if(x!=0){
        	
        	response.sendRedirect("user/EditProfile.jsp?q=Profile Photo Updated Successfully...");
        }
        else{
        	response.sendRedirect("user/EditProfile.jsp?q=Retry...");
        }
        }
        catch(Exception e){
        	
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

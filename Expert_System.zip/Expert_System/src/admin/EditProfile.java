package admin;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

/**
 * Servlet implementation class EditProfile
 */
@MultipartConfig
@WebServlet("/EditProfile")
public class EditProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
Part file=request.getPart("image");
        
        String imageFileName=file.getSubmittedFileName();// get selected image file name
        System.out.println(imageFileName);
        
        // upload path where the original image is going to be uploaded
        String uploadPath="C:/Users/lenovo/workspace/Expert_System/WebContent/admin/images/admin/"+imageFileName; 
        String uploadPath2="C:/Users/lenovo/workspace/Expert_System/WebContent/expert/images/admin/"+imageFileName; 
        String uploadPath3="C:/Users/lenovo/workspace/Expert_System/WebContent/user/images/admin/"+imageFileName; 

        System.out.print(uploadPath);
        
        // Uploading image into images folder
        try{
	        FileOutputStream fos=new FileOutputStream(uploadPath);
	        FileOutputStream fos2=new FileOutputStream(uploadPath2);
	        FileOutputStream fos3=new FileOutputStream(uploadPath3);
	        InputStream is=file.getInputStream();
	        InputStream is2=file.getInputStream();
	        InputStream is3=file.getInputStream();
	        
	        
	        byte[] data=new byte[is.available()];
	        byte[] data2=new byte[is2.available()];
	        byte[] data3=new byte[is3.available()];
	        is.read(data);
	        fos.write(data);
	        is2.read(data2);
	        fos2.write(data2);
	        is3.read(data3);
	        fos3.write(data3);
	        fos.close();
	        fos2.close();
	        fos3.close();
        }
        catch(Exception e){
        	e.printStackTrace();
        }
        
        // Database connectivity
        try{
        	HttpSession session=request.getSession();
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
        Statement st = conn.createStatement();
        int x=st.executeUpdate("update admin  SET `img` = '"+imageFileName+"' WHERE adminid='"+session.getAttribute("adminid")+"'");
            
        if(x!=0){
        	
        	response.sendRedirect("admin/EditProfile.jsp?q=Profile Photo Updated Successfully...");
        }
        else{
        	response.sendRedirect("admin/EditProfile.jsp?q=Retry...");
        }
        }
        catch(Exception e){
        	
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

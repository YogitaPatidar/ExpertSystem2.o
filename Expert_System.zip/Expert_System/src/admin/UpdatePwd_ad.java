package admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class UpdatePwd_ad
 */
@WebServlet("/UpdatePwd_ad")
public class UpdatePwd_ad extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// UPDATE `testing` SET `name` = 'Testing1', `password` = '123123' WHERE `testing`.`userid` = 2
		try{
        HttpSession session=request.getSession();
		Class.forName("com.mysql.jdbc.Driver");
	    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
	    Statement st = conn.createStatement();
		ResultSet res=st.executeQuery("select * from admin where adminid='"+session.getAttribute("adminid")+"'");
		while(res.next()){
			if(res.getString("password").equals(request.getParameter("oldpwd"))){
				if(res.getString("password").equals(request.getParameter("newpwd"))){
					response.sendRedirect("admin/Dashboard.jsp?q=Old and New Passwords are same...");
				}
				else{
					if(request.getParameter("newpwd").equals(request.getParameter("confirmpwd"))){
						int x=st.executeUpdate("UPDATE `admin` SET `password` = '"+request.getParameter("newpwd")+"' WHERE `admin`.`adminid` = '"+session.getAttribute("adminid")+"'");
						response.sendRedirect("admin/Dashboard.jsp?q=Password updated...");
					}
					else{
						response.sendRedirect("admin/Dashboard.jsp?q=Password mismatch...");
					}
				}
				
				
			}
			else{
				response.sendRedirect("admin/Dashboard.jsp?q= Enter correct Password");
				
			}
		}
		}
		catch(Exception e){
			
		}
	}

}

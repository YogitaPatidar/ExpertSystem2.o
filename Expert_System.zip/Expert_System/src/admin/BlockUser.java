package admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BlockUser
 */
@WebServlet("/BlockUser")
public class BlockUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			Class.forName("com.mysql.jdbc.Driver");
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
	        Statement st = conn.createStatement();
	        int x ;
	        if(Integer.parseInt(request.getParameter("status"))==0){
	        x= st.executeUpdate("UPDATE `user` SET `status` = '1' WHERE `user`.`userid` = '"+request.getParameter("id")+"';");
	        }
	        else{
	            x= st.executeUpdate("UPDATE `user` SET `status` = '0' WHERE `user`.`userid` = '"+request.getParameter("id")+"';");
	        }
			if(x!=0){
				response.sendRedirect("admin/BlockUser.jsp?s=Status changed...");
			}
			else{
				response.sendRedirect("admin/BlockUser.jsp?s=Retry...");
			}
			}
			catch(Exception e){
				
			}
			
		}

	}
